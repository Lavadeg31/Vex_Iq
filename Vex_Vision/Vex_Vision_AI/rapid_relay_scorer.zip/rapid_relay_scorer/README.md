# Rapid Relay AI Scorer

1. Install requirements:
   ```
   pip install -r requirements.txt
   ```

2. Run the scorer:
   ```
   python vision_ai.py 0  # For webcam
   python vision_ai.py path/to/video.mp4  # For video file
   ```
